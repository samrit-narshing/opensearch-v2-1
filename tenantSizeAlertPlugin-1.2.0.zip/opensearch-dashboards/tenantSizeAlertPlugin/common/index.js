"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'tenantSizeAlertPlugin';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'Tenant Size Alert (v1.0)';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsdUJBQWxCOztBQUNBLE1BQU1DLFdBQVcsR0FBRywwQkFBcEIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ3RlbmFudFNpemVBbGVydFBsdWdpbic7XG5leHBvcnQgY29uc3QgUExVR0lOX05BTUUgPSAnVGVuYW50IFNpemUgQWxlcnQgKHYxLjApJztcbiJdfQ==